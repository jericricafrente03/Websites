<!DOCTYPE html>
<html lang="en-US" class="no-js">

<head>
    <meta charset="UTF-8">
    <script src="<?php bloginfo('template_url'); ?>/js/myextension.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <script>
        WebFontConfig = {
            google: {
                families: ['Catamaran:300,400,600,700:latin,latin-ext', 'Raleway:100,700:latin,latin-ext', 'Roboto:700:latin,latin-ext']
            }
        };
    </script>
    <script id="litespeed-webfont-lib" src="https://ninetheme.com/themes/cryptoland/wp-content/plugins/litespeed-cache/js/webfontloader.min.js" async></script>
    <link data-optimized='2' rel='stylesheet' href='https://ninetheme.com/themes/cryptoland/min/acaa2.css' />
    <script data-optimized='1' src='https://ninetheme.com/themes/cryptoland/min/5d41e.js'></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="theme-color" content="#000">
    <title>Demo page &#8211; Jeric Ricafrente</title>
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='dns-prefetch' href='//s.w.org' />
    <link rel="alternate" type="application/rss+xml" title="Crypytoland &raquo; Feed" href="https://ninetheme.com/themes/cryptoland/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Crypytoland &raquo; Comments Feed" href="https://ninetheme.com/themes/cryptoland/comments/feed/" />
    <style id='cryptoland-custom-style-inline-css' type='text/css'>
        div#preloader {
            background-color: #fff;
            overflow: hidden;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100%;
            left: 0;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 10000
        }
        
        .loader05 {
            width: 56px;
            height: 56px;
            border: 4px solid #00d8d6;
            border-radius: 50%;
            position: relative;
            animation: loader-scale 1s ease-out infinite;
            top: 50%;
            margin: -28px auto 0
        }
        
        @keyframes loader-scale {
            0% {
                transform: scale(0);
                opacity: 0
            }
            50% {
                opacity: 1
            }
            100% {
                transform: scale(1);
                opacity: 0
            }
        }
        
        .c-backtop-1 {
            line-height: 50px!important
        }
        
        .c-backtop-1 i:before {
            font-size: 17px!important
        }
        
        .c-backtop-1 i {
            bottom: 50px!important
        }
        
        .c-backtop-1 {
            background-color: #8761a8;
            background-image: -webkit-gradient(linear, left top, right top, from(#8761a8), to(#f4929b));
            background-image: -webkit-linear-gradient(left, #8761a8 0, #f4929b 100%);
            background-image: -o-linear-gradient(left, #8761a8 0, #f4929b 100%);
            background-image: linear-gradient(to right, #8761a8 0, #f4929b 100%)
        }
        
        .nt-img-lg_d img {
            width: 45px !important
        }
        
        .nt-img-logo img {
            height: 51px !important
        }
        
        @media (max-width:1200px) {
            .fixed-menu .fixed-menu__content,
            .mob-menu__item {
                text-align: left!important
            }
        }
        
        .page-id-694.hero-fullwidth {
            background-image: url(https://ninetheme.com/themes/cryptoland/wp-content/themes/cryptoland/framework/images/main_bg.png)
        }
        
        .page-id-694 .header:not(.sticky) {
            background-color: transparent !important
        }
        
        .page-id-694.hero-fullwidth {
            background-image: url(https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/footer_bg.png)!important;
            background-size: cover!important;
            background-repeat: no-repeat!important;
            background-position: top center!important;
            background-attachment: fixed!important
        }
        
        .page-id-694.hero-fullwidth .hero-content {
            text-align: left !important
        }
        
        .footer-widget-area {
            padding-top: 96px !important
        }
        
        .footer-widget-area {
            padding-top: 500px !important
        }
        
        .copyright {
            padding-top: 44px !important;
            padding-bottom: 65px !important
        }
        
        .copyright {
            padding-top: 100 !important;
            padding-right: 200 !important
        }
    </style>
    <!--[if lt IE 9]> <script type='text/javascript' src='https://ninetheme.com/themes/cryptoland/wp-content/themes/cryptoland/framework/js/modernizr.min.js'></script> <![endif]-->
    <!--[if lt IE 9]> <script type='text/javascript' src='https://ninetheme.com/themes/cryptoland/wp-content/themes/cryptoland/framework/js/respond.min.js'></script> <![endif]-->
    <!--[if lt IE 9]> <script type='text/javascript' src='https://ninetheme.com/themes/cryptoland/wp-content/themes/cryptoland/js/html5shiv.min.js'></script> <![endif]-->
    <link rel='https://api.w.org/' href='https://ninetheme.com/themes/cryptoland/wp-json/' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://ninetheme.com/themes/cryptoland/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://ninetheme.com/themes/cryptoland/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.3.2" />
    <link rel="canonical" href="https://ninetheme.com/themes/cryptoland/demo-page/" />
    <link rel='shortlink' href='https://ninetheme.com/themes/cryptoland/?p=694' />
    <link rel="alternate" type="application/json+oembed" href="https://ninetheme.com/themes/cryptoland/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fninetheme.com%2Fthemes%2Fcryptoland%2Fdemo-page%2F" />
    <link rel="alternate" type="text/xml+oembed" href="https://ninetheme.com/themes/cryptoland/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fninetheme.com%2Fthemes%2Fcryptoland%2Fdemo-page%2F&#038;format=xml" />
    <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important
        }
    </style>
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
    <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://ninetheme.com/themes/cryptoland/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]-->
    <link rel="icon" href="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/cropped-graphic-32x32.png" sizes="32x32" />
    <link rel="icon" href="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/cropped-graphic-192x192.png" sizes="192x192" />
    <link rel="apple-touch-icon-precomposed" href="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/cropped-graphic-180x180.png" />
    <meta name="msapplication-TileImage" content="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/cropped-graphic-270x270.png" />
    <style type="text/css" id="wp-custom-css">
        @media (max-width:768px) {
            .wpb-js-composer .vc_general.vc_tta.vc_tta-accordion.vc_tta-color-cryptoland_vc_tta-color-purple .vc_tta-panel-title>a:before {
                right: 8.5px
            }
            .chart__wrap {
                position: relative;
                margin-bottom: 60px
            }
            .token__info-list {
                margin-bottom: 60px
            }
            img.platform__img {
                margin-top: 41px
            }
            .vc_custom_1538511914519 {
                text-align: center !important
            }
            .press-carousel .owl-dots {
                margin-top: 65px
            }
            .wpb_single_image.vc_align_left {
                text-align: center
            }
            .home3 .scroll-down {
                bottom: -70px
            }
            .wpb-js-composer .vc_general.vc_tta.vc_tta-accordion.vc_tta-color-cryptoland_vc_tta-color-transparent .vc_tta-panel-title>a:before {
                right: 7px
            }
            body #hero.hero-fullwidth {
                padding: 63% 15px 42%;
                max-height: 100% !important
            }
            .c-sidebar-1-widget {
                margin-bottom: 60px;
                padding: 0 !important
            }
        }
        
        @media (max-width:575px) {
            .c-blog-3-info {
                padding: 10px 0
            }
            .c-sidebar-1-widget {
                margin-bottom: 60px;
                padding: 0 !important
            }
        }
        
        #hero.first-screen p.breadcrumb {
            font-size: 16px;
            font-weight: 700;
            color: #fff
        }
        
        .breadcrumb a {
            color: #fff;
            margin: 0 3px
        }
        
        .flexslider .slides>li:before,
        .flex-direction-nav li:before,
        .flexslider ul li:before {
            width: 0
        }
        
        .flexslider .flex-direction-nav li {
            position: inherit
        }
        
        #gallery-1 .gallery-item {
            float: left;
            margin-top: 0;
            text-align: center;
            width: 33%
        }
        
        .c-sidebar-1-widget ol li,
        .c-sidebar-1-widget ul li {
            text-transform: capitalize
        }
        
        ul#recentcomments li span {
            color: #895faa;
            font-weight: 600
        }
    </style>
    <style type="text/css" data-type="vc_shortcodes-custom-css">
        .vc_custom_1540360800170 {
            margin-top: -150px !important;
            padding-right: 9% !important;
            padding-left: 9% !important;
            background-position: 0 0 !important;
            background-repeat: no-repeat !important
        }
        
        .vc_custom_1540360800174 {
            padding-right: 0 !important;
            padding-left: 0 !important
        }
        
        .vc_custom_1540359048911 {
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important
        }
        
        .vc_custom_1540359059418 {
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-size: cover !important
        }
        
        .vc_custom_1540359080183 {
            padding-top: 150px !important;
            padding-bottom: 150px !important
        }
        
        .vc_custom_1540359080186 {
            padding-top: 100px !important;
            padding-bottom: 100px !important
        }
        
        .vc_custom_1540359080189 {
            padding-top: 60px !important;
            padding-bottom: 60px !important
        }
        
        .vc_custom_1540360510666 {
            padding-top: 335px !important
        }
        
        .vc_custom_1540360053351 {
            margin-bottom: 0 !important
        }
        
        .vc_custom_1540356999079 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350166557 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350162382 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350124934 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350133185 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350139546 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1540350152419 {
            margin-bottom: 45px !important
        }
        
        .vc_custom_1543834387081 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1541247427480 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1543834602993 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1543834333918 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1541247635761 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1541247654753 {
            margin-bottom: 30px !important
        }
        
        .vc_custom_1540357921226 {
            margin-bottom: 80px !important
        }
        
        .vc_custom_1540357909168 {
            margin-top: 90px !important
        }
    </style>
    <noscript>
        <style type="text/css">
            .wpb_animate_when_almost_visible {
                opacity: 1
            }
        </style>
    </noscript>
</head>

<body class="page-template page-template-custom-page page-template-custom-page-php page page-id-694 nt-shortcode-1.0 home3 Ninetheme-Cryptoland Ninetheme-Version-1.0  wpb-js-composer js-comp-ver-5.7 vc_responsive">
    <div id="preloader" class="preloader">
        <div class="loader05"></div>
    </div>
    <header class="header sticky-on">
        <a class="logo nt-logo" href="#">
            <div class="logo__img bg-none nt-img-logo">
                <img class="static-logo" src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="100" height="500" alt="Logo">
                <img class="sticky-logo" src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="100" height="500" alt="Logo"></div>
            <div class="logo__title nt-text-logo">JericDesign</div>
        </a>
        <ul class="menu">
            <li class="menu__item">
                <a href="#0" title="    " class="menu__link"> </a>
            </li>
        </ul>
        <div class="header__right">
            <div class="sign-in-wrap">Sample Portfolio of Jeric Ricafrente BSCpE</div>
        </div>
        <div class="btn-menu">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>
        </div>
    </header>
    <div class="fixed-menu">
        <div class="fixed-menu__header">
            <a class="logo logo--color mob-sticky-text-logo nt-logo" href="https://ninetheme.com/themes/cryptoland/">
                <div class="logo__img bg-none nt-img-logo">
                    <img class="static-logo" src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="100" height="500" alt="Logo">
                    <img class="sticky-logo" src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/09/Logo_white.svg" width="100" height="500" alt="Logo"></div>
                <div class="logo__title nt-text-logo">JericDesign</div>
            </a>
            <div class="btn-close">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve" width="512px" height="512px">
                    <path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88   c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242   C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879   s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z" fill="#006DF0" />
                </svg>
            </div>
        </div>
        <div class="fixed-menu__content">
            <ul class="mob-menu">
                <li class="mob-menu__item">
                    <a href="#0" title="    " class="mob-menu__link"> </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="c-backtop-1 -js-backtop">
        <i class="c-backtop-1-icon fa fa-angle-up"></i></div>
    <div class="wrapper">
        <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="ult-responsive vc_row wpb_row vc_row-fluid overflow_visible zindex0 vc_row-no-padding vc_row-o-content-middle vc_row-flex">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper ">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1540360510666">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="vc_column-inner ">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_raw_code wpb_content_element wpb_raw_html vc_custom_1540360053351">
                                            <div class="wpb_wrapper">
                                                <div class="row justify-content-center align-items-center">
                                                    <div class="col-auto s-col">
                                                        <p class="__title">JericDesign</p>
                                                    </div>
                                                    <div class="col-auto s-col">
                                                        <p class="__subtitle">Creative Landing
                                                            <br> Pages &nbsp;<i>for</i> Internship</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="vc_column-inner ">
                                    <div class="wpb_wrapper ">
                                        <p style="font-size: 18px;color: #ffffff;line-height: 22px;text-align: center" class="ch_326369 vc_custom_heading vc_custom_1540356999079" data-res-css=" @media only screen and (max-width: 992px) {.ch_326369{}} @media only screen and (max-width: 768px) {.ch_326369{}} @media only screen and (max-width: 576px) {.ch_326369{}}">JericDesigns is a landing page made in CSS, Bootstrap and Javascript </p>
                                        <div class="btn-wrapper btn--center"><a href="#demos" class="btn btn-cases  btn--orange btn--medium"><span>See Demos</span></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="scene--wrap" id="start-screen" style="height:40vh;">
                            <canvas class="scene scene--full" id="scene"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <div id="demos" data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="ult-responsive vc_row wpb_row vc_row-fluid vc_custom_1540360800170 overflow_visible zindex1 vc_row-has-fill vc_column-gap-15" data-res-css=" @media only screen and (max-width: 992px) {.vc_custom_1540360800170{padding-right: 0px !important;padding-left: 0px !important;}}">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper ">
                        <div class="vc_row wpb_row vc_inner vc_row-fluid">
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350166557">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1543834387081 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://jericricafrente.000webhostapp.com/" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p1.png" class="vc_single_image-img attachment-full" alt="" srcset="" sizes="(max-width: 490px) 100vw, 490px" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_708008 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_708008{}} @media only screen and (max-width: 768px) {.ch_708008{}} @media only screen and (max-width: 576px) {.ch_708008{}}"><a href="https://ninetheme.com/themes/cryptoland/home-4" target=" _blank">Portfolio 1</a></h2></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350162382">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1541247427480 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://ninetheme.com/themes/cryptoland/home-2" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p2.png" class="vc_single_image-img attachment-full" alt="" srcset="" sizes="(max-width: 490px) 100vw, 490px" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_170649 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_170649{}} @media only screen and (max-width: 768px) {.ch_170649{}} @media only screen and (max-width: 576px) {.ch_170649{}}"><a href="https://ninetheme.com/themes/cryptoland/home-2" target=" _blank">Portfolio 2</a></h2></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350124934">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1543834602993 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://ninetheme.com/themes/cryptoland/" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p3.png" class="vc_single_image-img attachment-full" alt="" srcset="" sizes="(max-width: 490px) 100vw, 490px" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_494255 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_494255{}} @media only screen and (max-width: 768px) {.ch_494255{}} @media only screen and (max-width: 576px) {.ch_494255{}}"><a href="https://ninetheme.com/themes/cryptoland" target=" _blank">Portfolio 3</a></h2></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350133185">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1543834333918 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://ninetheme.com/themes/cryptoland/home-3" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p4.png" class="vc_single_image-img attachment-full" alt="" srcset="" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_831517 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_831517{}} @media only screen and (max-width: 768px) {.ch_831517{}} @media only screen and (max-width: 576px) {.ch_831517{}}"><a href="https://ninetheme.com/themes/cryptoland/home-3" target=" _blank">Portfolio 4</a></h2></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350139546">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1541247635761 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://ninetheme.com/themes/cryptoland/home-5" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p5.png" class="vc_single_image-img attachment-full" alt="" srcset="" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_158068 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_158068{}} @media only screen and (max-width: 768px) {.ch_158068{}} @media only screen and (max-width: 576px) {.ch_158068{}}"><a href="https://ninetheme.com/themes/cryptoland/home-5" target=" _blank">Portfolio 5</a></h2></div>
                                </div>
                            </div>
                            <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-4 vc_col-md-4 vc_col-xs-12">
                                <div class="vc_column-inner vc_custom_1540350152419">
                                    <div class="wpb_wrapper ">
                                        <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1541247654753 has_moveup">
                                            <figure class="wpb_wrapper vc_figure">
                                                <a href="https://ninetheme.com/themes/cryptoland/home-6" target="_blank" class="vc_single_image-wrapper   vc_box_border_grey"><img width="490" height="496" src="img/p6.png" class="vc_single_image-img attachment-full" alt="" srcset="" /> </a>
                                            </figure>
                                        </div>
                                        <h2 style="font-size: 20px;color: #ffffff;text-align: center" class="ch_722359 f-catamaran fw700 vc_custom_heading" data-res-css=" @media only screen and (max-width: 992px) {.ch_722359{}} @media only screen and (max-width: 768px) {.ch_722359{}} @media only screen and (max-width: 576px) {.ch_722359{}}"><a href="https://ninetheme.com/themes/cryptoland/home-6" target=" _blank">Portfolio 6</a></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="ult-responsive vc_row wpb_row vc_row-fluid vc_custom_1540359048911 bg-top-center overflow_visible zindex0 vc_row-has-fill vc_row-no-padding">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper "><img src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/video-bg-2.png" style=" width:100vw; min-width:1680px; height:auto; bottom:170px; left:0px;" alt="" class="absolute__bg horizontal-center"></div>
                </div>
            </div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="ult-responsive vc_row wpb_row vc_row-fluid vc_custom_1540359059418 bg-top-center overflow_visible zindex-1 vc_row-has-fill vc_row-no-padding">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper "><img src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/partenrs-bg-1.png" style=" width:100vw; min-width:1680px; height:auto; top:100px; left:0;" alt="" class="absolute__bg horizontal-center"></div>
                </div>
            </div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="ult-responsive vc_row wpb_row vc_row-fluid overflow_visible zindex-1 vc_row-no-padding">
            <div class="wpb_column vc_column_container vc_col-sm-12">
                <div class="vc_column-inner">
                    <div class="wpb_wrapper "><img src="https://ninetheme.com/themes/cryptoland/wp-content/uploads/2018/10/services-bg-1.png" style=" width:100vw; min-width:1680px; height:auto; top:-350px; left:0;" alt="" class="absolute__bg"></div>
                </div>
            </div>
        </div>
        <div class="vc_row-full-width vc_clearfix"></div>
        <div class="vc_row-full-width vc_clearfix"></div>
    </div>
    <script type='text/javascript'>
        var wpcf7 = {
            "apiSettings": {
                "root": "https:\/\/ninetheme.com\/themes\/cryptoland\/wp-json\/contact-form-7\/v1",
                "namespace": "contact-form-7\/v1"
            },
            "cached": "1"
        };
    </script>
    <script data-optimized='1' src='https://ninetheme.com/themes/cryptoland/min/c3a85.js'></script>
</body>

</html>